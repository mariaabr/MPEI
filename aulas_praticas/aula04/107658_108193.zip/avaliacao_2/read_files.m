udata = load("u.data");
u = udata(:,1:2); clear udata;

dic_movies = readcell('films.txt', 'Delimiter', '\t');

users = unique(u(:,1));
numusers = length(users);

movies_ids = cell(numusers,1);
for i = 1:numusers
    ind = find(u(:,1) == users(i));
    movies_ids{i} = [movies_ids{i} u(ind,2)];
end

save info_files dic_movies movies_ids