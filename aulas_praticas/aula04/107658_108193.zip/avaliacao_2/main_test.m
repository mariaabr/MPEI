load info_files;

prompt = "Insert User ID (1 to 943): \n";
validate = 0;

while validate == 0
    id = input(prompt, "s");
    id = str2double(id);

    if ((id < 1 || id > 943) || isnan(id))
        fprintf("não existe nenhum user com este id\n");
    else
        validate = 1;
    end
end

% menu

cab = "\n MENU\n1 - Your movies\n2 - Suggestion of movies based on other users\n" + ...
    "3 - Suggestion of movies based on already evaluated movies\n4 - Movies feedback based on popularity\n5 - Exit\n";

while true
    option = input(cab, "s");
    option = str2double(option);

    if (isnan(option))
        fprinf("a opção não existe");
    else
        switch option
            case 1
                my_movies(id, movies_ids, dic_movies);
            case 2
                sug_users(1);
            case 3
                sug_evaluated_movies(1);
            case 4
                feedback_popularity(1);
            case 5
                fprintf("exit\n");
                return;
            otherwise
                fprintf("a opção não existe\n");
        end
    end
end

% functions

function my_movies(id, movies_ids, dic_movies)
for i = movies_ids{id}' % i é um vetor linha
    fprintf("movie id %d: %s\n", i, dic_movies{i});
end
end

function sug_users()
    ...
end

        