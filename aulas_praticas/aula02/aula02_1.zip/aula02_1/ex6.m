%% por valores teoricos:

%alinea a)
P(um dois) = 1/9;
%alinea b)
P(pelo menos um um) = 5/9;
%alinea c)
P(U U D) = 8/9;
%alinea d)
P(U|D) = 2/5;